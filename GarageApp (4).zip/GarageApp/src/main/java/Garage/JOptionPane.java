/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Garage;

import javax.swing.JRootPane;

/**
 *
 * @author DELL
 */
class JOptionPane {

    static void showMessageDialog(JRootPane rootPane, String updated_Successfully) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
