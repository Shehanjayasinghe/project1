/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author Acer
 */
public class AddRepairJobs {
     private String id;
    private String employe;
    private String name;
    private String address;
    private String vehicleModel;
    private String vehicleNO;
    private String email;
    private String arrivalDate;
    private String departureDate;
    private String telephone;
    private String nic;
    private float price;

    public AddRepairJobs(String id, String employe, String name, String address, String vehicleModel, String vehicleNO, String email, String arrivalDate, String departureDate, String telephone, String nic, float price) {
        this.id = id;
        this.employe = employe;
        this.name = name;
        this.address = address;
        this.vehicleModel = vehicleModel;
        this.vehicleNO = vehicleNO;
        this.email = email;
        this.arrivalDate = arrivalDate;
        this.departureDate = departureDate;
        this.telephone = telephone;
        this.nic = nic;
        this.price = price;
    }
    
}
