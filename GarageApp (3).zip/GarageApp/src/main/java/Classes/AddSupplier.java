/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author Acer
 */
public class AddSupplier {
   private String supplierID;
    private String suppliername;
    private String telephone;
    private String sparepart;
    private String date;

    public AddSupplier(String supplierID, String suppliername, String telephone, String sparepart, String date) {
        this.supplierID = supplierID;
        this.suppliername = suppliername;
        this.telephone = telephone;
        this.sparepart = sparepart;
        this.date = date;
    }
    
}
