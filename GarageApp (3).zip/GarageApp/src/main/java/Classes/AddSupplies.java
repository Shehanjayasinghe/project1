/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author Acer
 */
public class AddSupplies {
    private String sparepartID;
    private String sparepartName;
    private int Quantity;
    private float price;
    private float totPrice;
    private String date;

    public AddSupplies(String sparepartID, String sparepartName, int Quantity, float price, float totPrice, String date) {
        this.sparepartID = sparepartID;
        this.sparepartName = sparepartName;
        this.Quantity = Quantity;
        this.price = price;
        this.totPrice = totPrice;
        this.date = date;
    }
    
}
